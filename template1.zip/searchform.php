<fieldset class="field-container">
	<form role="search" method="get" id="searchform" action="<?php echo get_site_url(); ?>">
		<input type="text" placeholder="Buscar..." class="field" name="s" id="search" value="" />
		<div class="icons-container">
		    <div class="icon-search"></div>
	  	</div>
	</form>
</fieldset>