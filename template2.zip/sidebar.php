<?php get_search_form(); ?>
<?php if(!function_exists('dynamic_sidebar') || !dynamic_sidebar('Sidebar')) : ?>
<?php endif; ?>